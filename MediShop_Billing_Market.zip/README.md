# MediShop Billing Market

Flask + SQLite medical shop billing and inventory demo.

## Run locally
1. Install Python 3.11 or newer.
2. Open this folder in CMD.
3. Run `python -m venv venv`
4. Run `venv\\Scripts\\activate` (Windows CMD)
5. Run `pip install -r requirements.txt`
6. Run `python app.py`
7. Open http://127.0.0.1:5000

Demo login: `admin` / `Admin@12345`

Change the admin password from Settings immediately. For deployment set `SECRET_KEY` and `ADMIN_PASSWORD`.

## Deploy online (Render)
1. Create a GitHub account and a new repository.
2. Upload all files in this folder to the repository (do not upload `medishop.db`).
3. In Render choose **New + → Blueprint**, connect the repository and deploy.
4. Set a strong `ADMIN_PASSWORD` in the Render environment settings before sharing the site.
5. Set a persistent disk and mount it at `/var/data`, then set the Render environment variable `DB_PATH` to `/var/data/medishop.db` if you need SQLite data to survive redeploys/restarts. Free hosting may sleep and may not provide persistent storage.
6. Use HTTPS URL provided by Render.

## Notes
- This is a starter/demo application. Validate GST settings, invoice wording, pharmacy regulations, data privacy and accounting with qualified professionals before commercial use.
- Barcode scanners that act like keyboards work: focus the barcode field and scan. A camera barcode reader is not included.
- The sample database is created automatically. Demo medicines and credentials are for testing only.
- SQLite is suitable for a small single-instance shop. For multi-user/high-traffic production, use managed PostgreSQL and backups.
- GST is calculated as a simple percentage on the entered selling price. Configure tax rates correctly for each product and confirm whether prices are tax-inclusive or tax-exclusive for your business.
