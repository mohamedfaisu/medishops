import os, sqlite3, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, g, abort, make_response
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("DB_PATH", os.path.join(APP_DIR, "medishop.db"))
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-before-deploy-" + secrets.token_hex(8))
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'staff');
    CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY, name TEXT NOT NULL, sku TEXT UNIQUE, barcode TEXT UNIQUE,
      category TEXT DEFAULT 'General', batch TEXT DEFAULT '', expiry TEXT DEFAULT '',
      purchase_price REAL NOT NULL DEFAULT 0, selling_price REAL NOT NULL DEFAULT 0,
      gst REAL NOT NULL DEFAULT 0, stock INTEGER NOT NULL DEFAULT 0,
      reorder_level INTEGER NOT NULL DEFAULT 5, prescription_required INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS sales(
      id INTEGER PRIMARY KEY, invoice_no TEXT UNIQUE NOT NULL, customer TEXT DEFAULT 'Walk-in Customer',
      phone TEXT DEFAULT '', subtotal REAL NOT NULL, gst_total REAL NOT NULL, discount REAL NOT NULL DEFAULT 0,
      grand_total REAL NOT NULL, payment_method TEXT DEFAULT 'Cash', created_by INTEGER,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(created_by) REFERENCES users(id));
    CREATE TABLE IF NOT EXISTS sale_items(
      id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
      product_name TEXT NOT NULL, batch TEXT, qty INTEGER NOT NULL, unit_price REAL NOT NULL,
      gst REAL NOT NULL, line_total REAL NOT NULL, FOREIGN KEY(sale_id) REFERENCES sales(id),
      FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS returns(
      id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL, sale_item_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL, qty INTEGER NOT NULL, reason TEXT DEFAULT '',
      refund REAL NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(sale_id) REFERENCES sales(id), FOREIGN KEY(sale_item_id) REFERENCES sale_items(id),
      FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS stock_log(
      id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL, change_qty INTEGER NOT NULL,
      note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(product_id) REFERENCES products(id));
    """)
    if not conn.execute("SELECT id FROM users WHERE username='admin'").fetchone():
        conn.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                     ("admin", generate_password_hash(os.environ.get("ADMIN_PASSWORD", "Admin@12345")), "admin"))
    if conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0:
        demo = [
          ("Paracetamol 500mg","MED-001","8901000000011","Tablet","B2401","2027-12-31",1.5,2.5,5,250,20,0),
          ("Vitamin C 500mg","MED-002","8901000000012","Supplement","VC2402","2027-08-31",4,6,5,90,15,0),
          ("ORS Sachet","MED-003","8901000000013","Healthcare","ORS2401","2027-06-30",12,18,5,60,10,0),
          ("Cetirizine 10mg","MED-004","8901000000014","Tablet","CT2401","2027-10-31",2,4,5,75,10,0),
        ]
        conn.executemany("""INSERT INTO products(name,sku,barcode,category,batch,expiry,purchase_price,selling_price,gst,stock,reorder_level,prescription_required)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", demo)
    conn.commit()
    conn.close()

init_db()

def login_required(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not session.get("user_id"): return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not session.get("user_id"): return redirect(url_for("login"))
        if session.get("role") != "admin": abort(403)
        return fn(*a, **kw)
    return wrapped

@app.before_request
def csrf_check():
    if request.method == "POST" and request.endpoint not in ("login",):
        token = session.get("_csrf")
        if not token or request.form.get("_csrf") != token:
            abort(400, "Invalid form token. Refresh the page and try again.")

@app.context_processor
def inject_globals():
    if "_csrf" not in session: session["_csrf"] = secrets.token_urlsafe(24)
    return {"csrf_token": session["_csrf"], "current_user": session.get("username"), "role": session.get("role")}

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        row = db().execute("SELECT * FROM users WHERE username=?", (request.form.get("username","").strip(),)).fetchone()
        if row and check_password_hash(row["password"], request.form.get("password","")):
            session.clear()
            session["user_id"], session["username"], session["role"] = row["id"], row["username"], row["role"]
            session["_csrf"] = secrets.token_urlsafe(24)
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/logout")
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    conn = db()
    today = datetime.now().strftime("%Y-%m-%d")
    sales = conn.execute("SELECT COUNT(*) c, COALESCE(SUM(grand_total),0) total FROM sales WHERE date(created_at)=?",(today,)).fetchone()
    products = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    low = conn.execute("SELECT COUNT(*) FROM products WHERE stock<=reorder_level").fetchone()[0]
    recent = conn.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 7").fetchall()
    low_items = conn.execute("SELECT * FROM products WHERE stock<=reorder_level ORDER BY stock ASC LIMIT 6").fetchall()
    return render_template("dashboard.html", sales=sales, products=products, low=low, recent=recent, low_items=low_items)

@app.route("/products")
@login_required
def products():
    q = request.args.get("q","").strip()
    rows = db().execute("""SELECT * FROM products WHERE name LIKE ? OR sku LIKE ? OR barcode LIKE ? ORDER BY name""",
                        (f"%{q}%",f"%{q}%",f"%{q}%")).fetchall()
    return render_template("products.html", products=rows, q=q)

@app.route("/products/add", methods=["GET","POST"])
@admin_required
def product_add():
    if request.method == "POST":
        try:
            db().execute("""INSERT INTO products(name,sku,barcode,category,batch,expiry,purchase_price,selling_price,gst,stock,reorder_level,prescription_required)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (
              request.form["name"].strip(), request.form.get("sku","").strip() or None,
              request.form.get("barcode","").strip() or None, request.form.get("category","General"),
              request.form.get("batch",""), request.form.get("expiry",""),
              float(request.form.get("purchase_price",0)), float(request.form["selling_price"]),
              float(request.form.get("gst",0)), int(request.form.get("stock",0)),
              int(request.form.get("reorder_level",5)), 1 if request.form.get("prescription_required") else 0))
            db().commit(); flash("Product added successfully.", "success"); return redirect(url_for("products"))
        except sqlite3.IntegrityError:
            flash("SKU or barcode already exists.", "error")
        except (ValueError, KeyError):
            flash("Check the product details and numeric values.", "error")
    return render_template("product_form.html")

@app.route("/products/<int:pid>/stock", methods=["POST"])
@admin_required
def stock_update(pid):
    qty = int(request.form.get("qty",0))
    if qty <= 0: flash("Stock addition must be greater than zero.", "error")
    else:
        conn=db(); conn.execute("UPDATE products SET stock=stock+? WHERE id=?",(qty,pid))
        conn.execute("INSERT INTO stock_log(product_id,change_qty,note) VALUES(?,?,?)",(pid,qty,"Manual stock addition"))
        conn.commit(); flash("Stock updated.", "success")
    return redirect(url_for("products"))

@app.route("/api/product")
@login_required
def product_lookup():
    code=request.args.get("code","")
    row=db().execute("SELECT id,name,barcode,stock,selling_price,gst,batch,expiry,prescription_required FROM products WHERE barcode=? OR sku=?",(code,code)).fetchone()
    return (dict(row) if row else {"error":"Product not found"}), (200 if row else 404)

@app.route("/billing")
@login_required
def billing():
    return render_template("billing.html")

@app.route("/checkout", methods=["POST"])
@login_required
def checkout():
    import json
    try:
        items=json.loads(request.form.get("cart","[]"))
        if not items: raise ValueError()
        conn=db(); prepared=[]; subtotal=0; gst_total=0
        for item in items:
            p=conn.execute("SELECT * FROM products WHERE id=?",(int(item["id"]),)).fetchone()
            qty=int(item["qty"])
            if not p or qty<1 or p["stock"]<qty: raise ValueError("Insufficient stock or invalid item.")
            price=float(p["selling_price"]); tax=price*qty*float(p["gst"])/100
            line=price*qty
            prepared.append((p,qty,price,tax,line)); subtotal+=line; gst_total+=tax
        discount=max(0,float(request.form.get("discount",0)))
        if discount > subtotal+gst_total: raise ValueError("Discount is too high.")
        total=subtotal+gst_total-discount
        invoice="MED-"+datetime.now().strftime("%y%m%d%H%M%S")+"-"+secrets.token_hex(2).upper()
        cur=conn.execute("""INSERT INTO sales(invoice_no,customer,phone,subtotal,gst_total,discount,grand_total,payment_method,created_by)
        VALUES(?,?,?,?,?,?,?,?,?)""",(invoice,request.form.get("customer","Walk-in Customer"),request.form.get("phone",""),subtotal,gst_total,discount,total,request.form.get("payment_method","Cash"),session["user_id"]))
        sid=cur.lastrowid
        for p,qty,price,tax,line in prepared:
            conn.execute("INSERT INTO sale_items(sale_id,product_id,product_name,batch,qty,unit_price,gst,line_total) VALUES(?,?,?,?,?,?,?,?)",
                         (sid,p["id"],p["name"],p["batch"],qty,price,p["gst"],line+tax))
            conn.execute("UPDATE products SET stock=stock-? WHERE id=?",(qty,p["id"]))
            conn.execute("INSERT INTO stock_log(product_id,change_qty,note) VALUES(?,?,?)",(p["id"],-qty,"Sale "+invoice))
        conn.commit()
        return redirect(url_for("invoice",sid=sid))
    except Exception as e:
        db().rollback(); flash(str(e) if str(e) else "Unable to complete bill. Check cart.", "error")
        return redirect(url_for("billing"))

@app.route("/invoice/<int:sid>")
@login_required
def invoice(sid):
    sale=db().execute("SELECT * FROM sales WHERE id=?",(sid,)).fetchone()
    if not sale: abort(404)
    items=db().execute("SELECT * FROM sale_items WHERE sale_id=?",(sid,)).fetchall()
    returned={r["sale_item_id"]:r["qty"] for r in db().execute("SELECT sale_item_id,SUM(qty) qty FROM returns WHERE sale_id=? GROUP BY sale_item_id",(sid,)).fetchall()}
    return render_template("invoice.html", sale=sale, items=items, returned=returned)

@app.route("/sales")
@login_required
def sales():
    rows=db().execute("SELECT * FROM sales ORDER BY id DESC LIMIT 200").fetchall()
    return render_template("sales.html", sales=rows)

@app.route("/returns", methods=["GET","POST"])
@login_required
def returns():
    conn=db()
    if request.method=="POST":
        try:
            item_id=int(request.form["sale_item_id"]); qty=int(request.form["qty"])
            item=conn.execute("SELECT si.*,s.id sid FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE si.id=?",(item_id,)).fetchone()
            already=conn.execute("SELECT COALESCE(SUM(qty),0) FROM returns WHERE sale_item_id=?",(item_id,)).fetchone()[0]
            if not item or qty<1 or qty>item["qty"]-already: raise ValueError("Return quantity exceeds the unreturned quantity.")
            refund=qty*item["unit_price"]*(1+item["gst"]/100)
            conn.execute("INSERT INTO returns(sale_id,sale_item_id,product_id,qty,reason,refund) VALUES(?,?,?,?,?,?)",
                         (item["sid"],item_id,item["product_id"],qty,request.form.get("reason",""),refund))
            conn.execute("UPDATE products SET stock=stock+? WHERE id=?",(qty,item["product_id"]))
            conn.execute("INSERT INTO stock_log(product_id,change_qty,note) VALUES(?,?,?)",(item["product_id"],qty,"Sales return"))
            conn.commit(); flash("Return recorded and stock restored.", "success")
        except Exception as e:
            conn.rollback(); flash(str(e), "error")
        return redirect(url_for("returns"))
    recent=conn.execute("""SELECT r.*,s.invoice_no,si.product_name FROM returns r JOIN sales s ON s.id=r.sale_id JOIN sale_items si ON si.id=r.sale_item_id ORDER BY r.id DESC LIMIT 50""").fetchall()
    return render_template("returns.html", recent=recent)

@app.route("/returns/find")
@login_required
def return_find():
    invoice=request.args.get("invoice","").strip()
    sale=db().execute("SELECT * FROM sales WHERE invoice_no=?",(invoice,)).fetchone()
    items=[]
    if sale:
        items=db().execute("""SELECT si.*, COALESCE((SELECT SUM(qty) FROM returns r WHERE r.sale_item_id=si.id),0) returned
        FROM sale_items si WHERE si.sale_id=?""",(sale["id"],)).fetchall()
    return render_template("return_find.html", sale=sale, items=items, invoice=invoice)

@app.route("/reports")
@admin_required
def reports():
    conn=db()
    daily=conn.execute("SELECT date(created_at) day,COUNT(*) bills,SUM(grand_total) total FROM sales GROUP BY date(created_at) ORDER BY day DESC LIMIT 14").fetchall()
    top=conn.execute("SELECT product_name,SUM(qty) qty FROM sale_items GROUP BY product_id ORDER BY qty DESC LIMIT 8").fetchall()
    return render_template("reports.html", daily=daily, top=top)

@app.route("/users", methods=["GET","POST"])
@admin_required
def users():
    conn=db()
    if request.method=="POST":
        try:
            conn.execute("INSERT INTO users(username,password,role) VALUES(?,?,?)",
                         (request.form["username"].strip(),generate_password_hash(request.form["password"]),request.form["role"]))
            conn.commit(); flash("User created.", "success")
        except sqlite3.IntegrityError: flash("Username already exists.", "error")
        return redirect(url_for("users"))
    return render_template("users.html", users=conn.execute("SELECT id,username,role FROM users ORDER BY id").fetchall())

@app.route("/settings", methods=["GET","POST"])
@admin_required
def settings():
    if request.method=="POST":
        username=request.form.get("username","").strip()
        password=request.form.get("password","")
        if password:
            db().execute("UPDATE users SET password=? WHERE id=?",(generate_password_hash(password),session["user_id"]))
            db().commit(); flash("Password changed. Sign in again next time.", "success")
        return redirect(url_for("settings"))
    return render_template("settings.html")

@app.errorhandler(403)
def forbidden(e): return render_template("error.html", code=403, message="Admin access required."),403
@app.errorhandler(404)
def not_found(e): return render_template("error.html", code=404, message="Page not found."),404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT",5000)), debug=False)
